#!/bin/sh

#workspace location
#######################################################################################
catkin_path="../.."
#######################################################################################

#The new_world.launch file to deploy the turtlebot in a custom world set by the user
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=/home/workspace/catkin/src/turtlebot_simulator/turtlebot_gazebo/worlds/MySampleWorld.world" &
sleep 5

#The gmapping_demo.launch to perform SLAM
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_gazebo gmapping_demo.launch" &
sleep 5

#The view_navigation.launch to view the map in Rviz
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_rviz_launchers view_navigation.launch" &
sleep 5

#The keyboard_teleop.launch to manually control the robot with the computer keyboard
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_teleop keyboard_teleop.launch"
