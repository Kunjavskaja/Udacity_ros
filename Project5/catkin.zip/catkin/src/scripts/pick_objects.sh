#!/bin/sh

#Set workspace location here 
#######################################################################################
catkin_path="../.."
#######################################################################################

#The new_world.launch file to deploy the turtlebot in a custom world set by the user
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_gazebo turtlebot_world.launch world_file:=/home/workspace/catkin/src/turtlebot_simulator/turtlebot_gazebo/worlds/MySampleWorld.world" &
sleep 10
#The new_amcl_demo.launch to localize the turtlebot
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_gazebo amcl_demo.launch map_file:=/home/workspace/catkin/src/maps/map.yaml" &
sleep 15
#The view_navigation.launch to view the map in Rviz
xterm -e "cd ${catkin_path} && source devel/setup.bash && roslaunch turtlebot_rviz_launchers view_navigation.launch" &
sleep 15
#The pick objects node 
xterm -e "cd ${catkin_path} && source devel/setup.bash && rosrun pick_objects pick_objects" 
