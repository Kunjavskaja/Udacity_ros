^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package turtlebot_interactive_markers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.3.1 (2015-03-23)
------------------

2.3.0 (2014-12-30)
------------------

2.2.2 (2013-10-25)
------------------
* Correct reference to renamed launcher.
* Add missing install rule for the server.

2.2.1 (2013-09-11)
------------------

2.2.0 (2013-08-30)
------------------
* Add bugtracker and repo info URLs.
* Changelogs at package level.


2.1.x - hydro, unstable
=======================

2.1.1 (2013-07-23)
------------------

2.1.0 (2013-07-16)
------------------
* Catkinized


Previous versions, bugfixing
============================

Available in ROS wiki: http://ros.org/wiki/turtlebot_viz/ChangeList
