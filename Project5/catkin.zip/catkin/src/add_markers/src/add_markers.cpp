#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
// Time based implementation

int main( int argc, char** argv )
{
  ros::init(argc, argv, "add_markers");
  ros::NodeHandle n;
  ros::Rate r(1);
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 0,true);

  // Set our initial shape type to be a cube
  uint32_t shape = visualization_msgs::Marker::CUBE;

  while (ros::ok())
  {
    visualization_msgs::Marker marker;
    // Set the frame ID and timestamp, have to be defined before publishing
    // Define first marker
    marker.header.frame_id = "map";
    marker.header.stamp = ros::Time::now();
    marker.ns = "basic_shapes";
    marker.id = 0;

    // Set the marker type, same as in example video
    marker.type = shape;
    marker.action = visualization_msgs::Marker::ADD;
    marker.lifetime = ros::Duration(13);
    ROS_INFO("Publishing marker to starting location");
    sleep(2);

    // Define first marker
    marker.pose.position.x = -4.68511632944;
    marker.pose.position.y = -0.49108887277;
    marker.pose.position.z = 0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 0.739356214721;
    marker.scale.x = 0.3;
    marker.scale.y = 0.3;
    marker.scale.z = 0.3;
    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;
    marker_pub.publish(marker);
    ROS_INFO("Publishing marker to starting location");
    marker.action = visualization_msgs::Marker::DELETE;

	
    sleep(36);
    ros::Publisher marker_pub2 = n.advertise<visualization_msgs::Marker>("visualization_marker", 1,true);

    ROS_INFO("Publishing marker to drop-off location");
    visualization_msgs::Marker marker2;
    marker2.header.frame_id = "map";
    marker2.header.stamp = ros::Time();
    marker2.ns = "basic_shapes";
    marker2.id = 1;
    marker2.type = visualization_msgs::Marker::CUBE;
    marker2.action = visualization_msgs::Marker::ADD;

    // Define second marker
    marker2.pose.position.x = -4.33477251759;
    marker2.pose.position.y = 3.46157274646;
    marker2.pose.position.z = 0;
    marker2.pose.orientation.x = 0.0;
    marker2.pose.orientation.y = 0.0;
    marker2.pose.orientation.z = 0.0;
    marker2.pose.orientation.w = 0.728168664263;

    marker2.scale.x = 0.3;
    marker2.scale.y = 0.3;
    marker2.scale.z = 0.3;

    marker2.color.r = 0.0f;
    marker2.color.g = 1.0f;
    marker2.color.b = 0.0f;
    marker2.color.a = 1.0;

    marker_pub2.publish(marker2);
    marker2.lifetime = ros::Duration();
    ROS_INFO("Marker published to drop-off location");


    while(ros::ok()){
        ros::spinOnce();
    }
    r.sleep();
  }
}


